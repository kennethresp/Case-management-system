<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpassword = '';
$conn = mysql_connect($dbhost,$dbuser,$dbpassword);
mysql_select_db('majestic');
?>